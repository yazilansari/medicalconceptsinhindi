<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-19 23:56:02 --> Config Class Initialized
INFO - 2020-11-19 23:56:02 --> Hooks Class Initialized
DEBUG - 2020-11-19 23:56:02 --> UTF-8 Support Enabled
INFO - 2020-11-19 23:56:02 --> Utf8 Class Initialized
INFO - 2020-11-19 23:56:02 --> URI Class Initialized
INFO - 2020-11-19 23:56:02 --> Router Class Initialized
INFO - 2020-11-19 23:56:02 --> Output Class Initialized
INFO - 2020-11-19 23:56:02 --> Security Class Initialized
DEBUG - 2020-11-19 23:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 23:56:02 --> Input Class Initialized
INFO - 2020-11-19 23:56:02 --> Language Class Initialized
INFO - 2020-11-19 23:56:02 --> Language Class Initialized
INFO - 2020-11-19 23:56:02 --> Config Class Initialized
INFO - 2020-11-19 23:56:02 --> Loader Class Initialized
INFO - 2020-11-19 23:56:02 --> Helper loaded: url_helper
INFO - 2020-11-19 23:56:02 --> Helper loaded: form_helper
INFO - 2020-11-19 23:56:02 --> Helper loaded: html_helper
INFO - 2020-11-19 23:56:02 --> Helper loaded: security_helper
INFO - 2020-11-19 23:56:02 --> Database Driver Class Initialized
DEBUG - 2020-11-19 23:56:02 --> Session: Initialization under CLI aborted.
INFO - 2020-11-19 23:56:02 --> Controller Class Initialized
INFO - 2020-11-19 23:56:02 --> Helper loaded: upload_helper
INFO - 2020-11-19 23:56:02 --> Helper loaded: image_upload_helper
INFO - 2020-11-19 23:56:02 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-19 23:56:02 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-19 23:56:02 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/cron/models/Mdl_notification_request.php
INFO - 2020-11-19 23:56:02 --> Helper loaded: notification_helper
DEBUG - 2020-11-19 23:56:02 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-19 23:56:02 --> Database Forge Class Initialized
INFO - 2020-11-19 23:56:02 --> User Agent Class Initialized
ERROR - 2020-11-19 23:56:02 --> Query error: Column 'request_uri' cannot be null - Invalid query: INSERT INTO `usertracking` (`session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`, `http_method`, `post_parameters`, `get_parameters`, `raw_parameters`, `insert_datetime`, `user_identifier`) VALUES ('', NULL, 1605810362, NULL, NULL, '', '', '[]', '[]', '', '2020-11-19 23:56:02', 0)
INFO - 2020-11-19 23:57:01 --> Config Class Initialized
INFO - 2020-11-19 23:57:01 --> Hooks Class Initialized
DEBUG - 2020-11-19 23:57:01 --> UTF-8 Support Enabled
INFO - 2020-11-19 23:57:01 --> Utf8 Class Initialized
INFO - 2020-11-19 23:57:01 --> URI Class Initialized
INFO - 2020-11-19 23:57:01 --> Router Class Initialized
INFO - 2020-11-19 23:57:01 --> Output Class Initialized
INFO - 2020-11-19 23:57:01 --> Security Class Initialized
DEBUG - 2020-11-19 23:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 23:57:01 --> Input Class Initialized
INFO - 2020-11-19 23:57:01 --> Language Class Initialized
INFO - 2020-11-19 23:57:01 --> Language Class Initialized
INFO - 2020-11-19 23:57:01 --> Config Class Initialized
INFO - 2020-11-19 23:57:01 --> Loader Class Initialized
INFO - 2020-11-19 23:57:01 --> Helper loaded: url_helper
INFO - 2020-11-19 23:57:01 --> Helper loaded: form_helper
INFO - 2020-11-19 23:57:01 --> Helper loaded: html_helper
INFO - 2020-11-19 23:57:01 --> Helper loaded: security_helper
INFO - 2020-11-19 23:57:01 --> Database Driver Class Initialized
DEBUG - 2020-11-19 23:57:01 --> Session: Initialization under CLI aborted.
INFO - 2020-11-19 23:57:01 --> Controller Class Initialized
INFO - 2020-11-19 23:57:01 --> Helper loaded: upload_helper
INFO - 2020-11-19 23:57:01 --> Helper loaded: image_upload_helper
INFO - 2020-11-19 23:57:01 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-19 23:57:01 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-19 23:57:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/cron/models/Mdl_notification_request.php
INFO - 2020-11-19 23:57:01 --> Helper loaded: notification_helper
DEBUG - 2020-11-19 23:57:01 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-19 23:57:01 --> Database Forge Class Initialized
INFO - 2020-11-19 23:57:01 --> User Agent Class Initialized
ERROR - 2020-11-19 23:57:01 --> Query error: Column 'request_uri' cannot be null - Invalid query: INSERT INTO `usertracking` (`session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`, `http_method`, `post_parameters`, `get_parameters`, `raw_parameters`, `insert_datetime`, `user_identifier`) VALUES ('', NULL, 1605810421, NULL, NULL, '', '', '[]', '[]', '', '2020-11-19 23:57:01', 0)
INFO - 2020-11-19 23:58:01 --> Config Class Initialized
INFO - 2020-11-19 23:58:01 --> Hooks Class Initialized
DEBUG - 2020-11-19 23:58:01 --> UTF-8 Support Enabled
INFO - 2020-11-19 23:58:01 --> Utf8 Class Initialized
INFO - 2020-11-19 23:58:01 --> URI Class Initialized
INFO - 2020-11-19 23:58:01 --> Router Class Initialized
INFO - 2020-11-19 23:58:01 --> Output Class Initialized
INFO - 2020-11-19 23:58:01 --> Security Class Initialized
DEBUG - 2020-11-19 23:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 23:58:01 --> Input Class Initialized
INFO - 2020-11-19 23:58:01 --> Language Class Initialized
INFO - 2020-11-19 23:58:01 --> Language Class Initialized
INFO - 2020-11-19 23:58:01 --> Config Class Initialized
INFO - 2020-11-19 23:58:01 --> Loader Class Initialized
INFO - 2020-11-19 23:58:01 --> Helper loaded: url_helper
INFO - 2020-11-19 23:58:01 --> Helper loaded: form_helper
INFO - 2020-11-19 23:58:01 --> Helper loaded: html_helper
INFO - 2020-11-19 23:58:01 --> Helper loaded: security_helper
INFO - 2020-11-19 23:58:01 --> Database Driver Class Initialized
DEBUG - 2020-11-19 23:58:01 --> Session: Initialization under CLI aborted.
INFO - 2020-11-19 23:58:01 --> Controller Class Initialized
INFO - 2020-11-19 23:58:01 --> Helper loaded: upload_helper
INFO - 2020-11-19 23:58:01 --> Helper loaded: image_upload_helper
INFO - 2020-11-19 23:58:01 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-19 23:58:01 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-19 23:58:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/cron/models/Mdl_notification_request.php
INFO - 2020-11-19 23:58:01 --> Helper loaded: notification_helper
DEBUG - 2020-11-19 23:58:01 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-19 23:58:01 --> Database Forge Class Initialized
INFO - 2020-11-19 23:58:01 --> User Agent Class Initialized
ERROR - 2020-11-19 23:58:01 --> Query error: Column 'request_uri' cannot be null - Invalid query: INSERT INTO `usertracking` (`session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`, `http_method`, `post_parameters`, `get_parameters`, `raw_parameters`, `insert_datetime`, `user_identifier`) VALUES ('', NULL, 1605810481, NULL, NULL, '', '', '[]', '[]', '', '2020-11-19 23:58:01', 0)
INFO - 2020-11-19 23:59:01 --> Config Class Initialized
INFO - 2020-11-19 23:59:01 --> Hooks Class Initialized
DEBUG - 2020-11-19 23:59:01 --> UTF-8 Support Enabled
INFO - 2020-11-19 23:59:01 --> Utf8 Class Initialized
INFO - 2020-11-19 23:59:01 --> URI Class Initialized
INFO - 2020-11-19 23:59:01 --> Router Class Initialized
INFO - 2020-11-19 23:59:01 --> Output Class Initialized
INFO - 2020-11-19 23:59:01 --> Security Class Initialized
DEBUG - 2020-11-19 23:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 23:59:01 --> Input Class Initialized
INFO - 2020-11-19 23:59:01 --> Language Class Initialized
INFO - 2020-11-19 23:59:01 --> Language Class Initialized
INFO - 2020-11-19 23:59:01 --> Config Class Initialized
INFO - 2020-11-19 23:59:01 --> Loader Class Initialized
INFO - 2020-11-19 23:59:01 --> Helper loaded: url_helper
INFO - 2020-11-19 23:59:01 --> Helper loaded: form_helper
INFO - 2020-11-19 23:59:01 --> Helper loaded: html_helper
INFO - 2020-11-19 23:59:01 --> Helper loaded: security_helper
INFO - 2020-11-19 23:59:01 --> Database Driver Class Initialized
DEBUG - 2020-11-19 23:59:01 --> Session: Initialization under CLI aborted.
INFO - 2020-11-19 23:59:01 --> Controller Class Initialized
INFO - 2020-11-19 23:59:01 --> Helper loaded: upload_helper
INFO - 2020-11-19 23:59:01 --> Helper loaded: image_upload_helper
INFO - 2020-11-19 23:59:01 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-19 23:59:01 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-19 23:59:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/cron/models/Mdl_notification_request.php
INFO - 2020-11-19 23:59:01 --> Helper loaded: notification_helper
DEBUG - 2020-11-19 23:59:01 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-19 23:59:01 --> Database Forge Class Initialized
INFO - 2020-11-19 23:59:01 --> User Agent Class Initialized
ERROR - 2020-11-19 23:59:01 --> Query error: Column 'request_uri' cannot be null - Invalid query: INSERT INTO `usertracking` (`session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`, `http_method`, `post_parameters`, `get_parameters`, `raw_parameters`, `insert_datetime`, `user_identifier`) VALUES ('', NULL, 1605810541, NULL, NULL, '', '', '[]', '[]', '', '2020-11-19 23:59:01', 0)
