<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-18 23:56:32 --> Config Class Initialized
INFO - 2020-11-18 23:56:32 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:56:32 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:56:32 --> Utf8 Class Initialized
INFO - 2020-11-18 23:56:32 --> URI Class Initialized
INFO - 2020-11-18 23:56:32 --> Router Class Initialized
INFO - 2020-11-18 23:56:32 --> Output Class Initialized
INFO - 2020-11-18 23:56:32 --> Security Class Initialized
DEBUG - 2020-11-18 23:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:56:32 --> Input Class Initialized
INFO - 2020-11-18 23:56:32 --> Language Class Initialized
INFO - 2020-11-18 23:56:32 --> Language Class Initialized
INFO - 2020-11-18 23:56:32 --> Config Class Initialized
INFO - 2020-11-18 23:56:32 --> Loader Class Initialized
INFO - 2020-11-18 23:56:32 --> Helper loaded: url_helper
INFO - 2020-11-18 23:56:32 --> Helper loaded: form_helper
INFO - 2020-11-18 23:56:32 --> Helper loaded: html_helper
INFO - 2020-11-18 23:56:32 --> Helper loaded: security_helper
INFO - 2020-11-18 23:56:32 --> Database Driver Class Initialized
DEBUG - 2020-11-18 23:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 23:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 23:56:32 --> Controller Class Initialized
INFO - 2020-11-18 23:56:32 --> Helper loaded: upload_helper
INFO - 2020-11-18 23:56:32 --> Helper loaded: image_upload_helper
INFO - 2020-11-18 23:56:32 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-18 23:56:32 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-18 23:56:32 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Api_model.php
INFO - 2020-11-18 23:56:32 --> Helper loaded: common_helper
DEBUG - 2020-11-18 23:56:32 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Category_model.php
DEBUG - 2020-11-18 23:56:32 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Upload_data_model.php
DEBUG - 2020-11-18 23:56:32 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Common_model.php
DEBUG - 2020-11-18 23:56:32 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Login_model.php
DEBUG - 2020-11-18 23:56:33 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-18 23:56:33 --> Database Forge Class Initialized
INFO - 2020-11-18 23:56:33 --> User Agent Class Initialized
INFO - 2020-11-18 23:56:33 --> Final output sent to browser
DEBUG - 2020-11-18 23:56:33 --> Total execution time: 0.6783
INFO - 2020-11-18 23:56:36 --> Config Class Initialized
INFO - 2020-11-18 23:56:36 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:56:36 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:56:36 --> Utf8 Class Initialized
INFO - 2020-11-18 23:56:36 --> URI Class Initialized
INFO - 2020-11-18 23:56:36 --> Router Class Initialized
INFO - 2020-11-18 23:56:36 --> Output Class Initialized
INFO - 2020-11-18 23:56:36 --> Security Class Initialized
DEBUG - 2020-11-18 23:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:56:36 --> Input Class Initialized
INFO - 2020-11-18 23:56:36 --> Language Class Initialized
ERROR - 2020-11-18 23:56:36 --> 404 Page Not Found: /index
INFO - 2020-11-18 23:56:37 --> Config Class Initialized
INFO - 2020-11-18 23:56:37 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:56:37 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:56:37 --> Utf8 Class Initialized
INFO - 2020-11-18 23:56:37 --> URI Class Initialized
INFO - 2020-11-18 23:56:37 --> Router Class Initialized
INFO - 2020-11-18 23:56:37 --> Output Class Initialized
INFO - 2020-11-18 23:56:37 --> Security Class Initialized
DEBUG - 2020-11-18 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:56:37 --> Input Class Initialized
INFO - 2020-11-18 23:56:37 --> Language Class Initialized
ERROR - 2020-11-18 23:56:37 --> 404 Page Not Found: /index
INFO - 2020-11-18 23:56:50 --> Config Class Initialized
INFO - 2020-11-18 23:56:50 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:56:50 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:56:50 --> Utf8 Class Initialized
INFO - 2020-11-18 23:56:50 --> URI Class Initialized
INFO - 2020-11-18 23:56:50 --> Router Class Initialized
INFO - 2020-11-18 23:56:50 --> Output Class Initialized
INFO - 2020-11-18 23:56:50 --> Security Class Initialized
DEBUG - 2020-11-18 23:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:56:50 --> Input Class Initialized
INFO - 2020-11-18 23:56:50 --> Language Class Initialized
INFO - 2020-11-18 23:56:50 --> Language Class Initialized
INFO - 2020-11-18 23:56:50 --> Config Class Initialized
INFO - 2020-11-18 23:56:50 --> Loader Class Initialized
INFO - 2020-11-18 23:56:50 --> Helper loaded: url_helper
INFO - 2020-11-18 23:56:50 --> Helper loaded: form_helper
INFO - 2020-11-18 23:56:50 --> Helper loaded: html_helper
INFO - 2020-11-18 23:56:50 --> Helper loaded: security_helper
INFO - 2020-11-18 23:56:50 --> Database Driver Class Initialized
DEBUG - 2020-11-18 23:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 23:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 23:56:50 --> Controller Class Initialized
INFO - 2020-11-18 23:56:50 --> Helper loaded: upload_helper
INFO - 2020-11-18 23:56:50 --> Helper loaded: image_upload_helper
INFO - 2020-11-18 23:56:50 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-18 23:56:50 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-18 23:56:50 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Api_model.php
INFO - 2020-11-18 23:56:50 --> Helper loaded: common_helper
DEBUG - 2020-11-18 23:56:50 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Category_model.php
DEBUG - 2020-11-18 23:56:50 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Upload_data_model.php
DEBUG - 2020-11-18 23:56:50 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Common_model.php
DEBUG - 2020-11-18 23:56:50 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Login_model.php
DEBUG - 2020-11-18 23:56:51 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-18 23:56:51 --> Database Forge Class Initialized
INFO - 2020-11-18 23:56:51 --> User Agent Class Initialized
INFO - 2020-11-18 23:56:51 --> Final output sent to browser
DEBUG - 2020-11-18 23:56:51 --> Total execution time: 0.9812
INFO - 2020-11-18 23:57:01 --> Config Class Initialized
INFO - 2020-11-18 23:57:01 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:57:01 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:57:01 --> Utf8 Class Initialized
INFO - 2020-11-18 23:57:01 --> URI Class Initialized
INFO - 2020-11-18 23:57:01 --> Router Class Initialized
INFO - 2020-11-18 23:57:01 --> Output Class Initialized
INFO - 2020-11-18 23:57:01 --> Security Class Initialized
DEBUG - 2020-11-18 23:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:57:01 --> Input Class Initialized
INFO - 2020-11-18 23:57:01 --> Language Class Initialized
INFO - 2020-11-18 23:57:01 --> Language Class Initialized
INFO - 2020-11-18 23:57:01 --> Config Class Initialized
INFO - 2020-11-18 23:57:01 --> Loader Class Initialized
INFO - 2020-11-18 23:57:01 --> Helper loaded: url_helper
INFO - 2020-11-18 23:57:01 --> Helper loaded: form_helper
INFO - 2020-11-18 23:57:01 --> Helper loaded: html_helper
INFO - 2020-11-18 23:57:01 --> Helper loaded: security_helper
INFO - 2020-11-18 23:57:01 --> Database Driver Class Initialized
DEBUG - 2020-11-18 23:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 23:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 23:57:01 --> Controller Class Initialized
INFO - 2020-11-18 23:57:01 --> Helper loaded: upload_helper
INFO - 2020-11-18 23:57:01 --> Helper loaded: image_upload_helper
INFO - 2020-11-18 23:57:01 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-18 23:57:01 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-18 23:57:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Api_model.php
INFO - 2020-11-18 23:57:01 --> Helper loaded: common_helper
DEBUG - 2020-11-18 23:57:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Category_model.php
DEBUG - 2020-11-18 23:57:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Upload_data_model.php
DEBUG - 2020-11-18 23:57:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Common_model.php
DEBUG - 2020-11-18 23:57:01 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Login_model.php
DEBUG - 2020-11-18 23:57:01 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-18 23:57:01 --> Database Forge Class Initialized
INFO - 2020-11-18 23:57:01 --> User Agent Class Initialized
INFO - 2020-11-18 23:57:01 --> Final output sent to browser
DEBUG - 2020-11-18 23:57:01 --> Total execution time: 0.0975
INFO - 2020-11-18 23:57:09 --> Config Class Initialized
INFO - 2020-11-18 23:57:09 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:57:09 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:57:09 --> Utf8 Class Initialized
INFO - 2020-11-18 23:57:09 --> URI Class Initialized
INFO - 2020-11-18 23:57:09 --> Router Class Initialized
INFO - 2020-11-18 23:57:09 --> Output Class Initialized
INFO - 2020-11-18 23:57:09 --> Security Class Initialized
DEBUG - 2020-11-18 23:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:57:09 --> Input Class Initialized
INFO - 2020-11-18 23:57:09 --> Language Class Initialized
INFO - 2020-11-18 23:57:09 --> Language Class Initialized
INFO - 2020-11-18 23:57:09 --> Config Class Initialized
INFO - 2020-11-18 23:57:09 --> Loader Class Initialized
INFO - 2020-11-18 23:57:09 --> Helper loaded: url_helper
INFO - 2020-11-18 23:57:09 --> Helper loaded: form_helper
INFO - 2020-11-18 23:57:09 --> Helper loaded: html_helper
INFO - 2020-11-18 23:57:09 --> Helper loaded: security_helper
INFO - 2020-11-18 23:57:09 --> Database Driver Class Initialized
DEBUG - 2020-11-18 23:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 23:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 23:57:09 --> Controller Class Initialized
INFO - 2020-11-18 23:57:09 --> Helper loaded: upload_helper
INFO - 2020-11-18 23:57:09 --> Helper loaded: image_upload_helper
INFO - 2020-11-18 23:57:09 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-18 23:57:09 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-18 23:57:09 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Api_model.php
INFO - 2020-11-18 23:57:09 --> Helper loaded: common_helper
DEBUG - 2020-11-18 23:57:09 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Upload_data_model.php
DEBUG - 2020-11-18 23:57:09 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Common_model.php
DEBUG - 2020-11-18 23:57:09 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Login_model.php
DEBUG - 2020-11-18 23:57:09 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-18 23:57:09 --> Database Forge Class Initialized
INFO - 2020-11-18 23:57:09 --> User Agent Class Initialized
INFO - 2020-11-18 23:57:09 --> Final output sent to browser
DEBUG - 2020-11-18 23:57:09 --> Total execution time: 0.2584
INFO - 2020-11-18 23:57:45 --> Config Class Initialized
INFO - 2020-11-18 23:57:45 --> Hooks Class Initialized
DEBUG - 2020-11-18 23:57:45 --> UTF-8 Support Enabled
INFO - 2020-11-18 23:57:45 --> Utf8 Class Initialized
INFO - 2020-11-18 23:57:45 --> URI Class Initialized
INFO - 2020-11-18 23:57:45 --> Router Class Initialized
INFO - 2020-11-18 23:57:45 --> Output Class Initialized
INFO - 2020-11-18 23:57:45 --> Security Class Initialized
DEBUG - 2020-11-18 23:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 23:57:45 --> Input Class Initialized
INFO - 2020-11-18 23:57:45 --> Language Class Initialized
INFO - 2020-11-18 23:57:45 --> Language Class Initialized
INFO - 2020-11-18 23:57:45 --> Config Class Initialized
INFO - 2020-11-18 23:57:45 --> Loader Class Initialized
INFO - 2020-11-18 23:57:45 --> Helper loaded: url_helper
INFO - 2020-11-18 23:57:45 --> Helper loaded: form_helper
INFO - 2020-11-18 23:57:45 --> Helper loaded: html_helper
INFO - 2020-11-18 23:57:45 --> Helper loaded: security_helper
INFO - 2020-11-18 23:57:45 --> Database Driver Class Initialized
DEBUG - 2020-11-18 23:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 23:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 23:57:45 --> Controller Class Initialized
INFO - 2020-11-18 23:57:45 --> Helper loaded: upload_helper
INFO - 2020-11-18 23:57:45 --> Helper loaded: image_upload_helper
INFO - 2020-11-18 23:57:45 --> Helper loaded: upload_pdf_helper
INFO - 2020-11-18 23:57:45 --> Helper loaded: upload_audio_video_helper
DEBUG - 2020-11-18 23:57:45 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Api_model.php
INFO - 2020-11-18 23:57:45 --> Helper loaded: common_helper
DEBUG - 2020-11-18 23:57:45 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Upload_data_model.php
DEBUG - 2020-11-18 23:57:45 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Common_model.php
DEBUG - 2020-11-18 23:57:45 --> File loaded: /www/live/medicalconceptsinhindi/application/modules/api/models/Login_model.php
DEBUG - 2020-11-18 23:57:45 --> Config file loaded: /www/live/medicalconceptsinhindi/application/config/usertracking.php
INFO - 2020-11-18 23:57:45 --> Database Forge Class Initialized
INFO - 2020-11-18 23:57:45 --> User Agent Class Initialized
INFO - 2020-11-18 23:57:45 --> Final output sent to browser
DEBUG - 2020-11-18 23:57:45 --> Total execution time: 0.0613
